public class DijkstraCalculator {
	private Stack<Double> numbers = new Stack<Double>();
	private Stack<String> operators = new Stack<String>();

	

	public boolean isOperator(String s) {
		if ("+".equals(s))
			return true;
		if ("-".equals(s))
			return true;
		if ("/".equals(s))
			return true;
		if ("*".equals(s))
			return true;
		if("sqrt".equals(s))
			return true;
		return false;
	}

	public double operate(String op, Double num) {
		if (op.equals("+"))
			return numbers.pop() + num;
		if (op.equals("-"))
			return numbers.pop() - num;
		if (op.equals("*"))
			return numbers.pop() * num;
		if (op.equals("/"))
			return numbers.pop() / num;
		if (op.equals("sqrt")) {

			double root = num;
			return root*root;
		}
		return -1;
	}

	public String calculate(String[] s) {
		for (String item : s) {
			if ("(".equals(item))
				;
			else if (isOperator(item))
				operators.push(item);
				
			else if (")".equals(item)) {
				double num = operate(operators.pop(), numbers.pop());
				numbers.push(num);
			} else {
				numbers.push(Double.parseDouble(item));
			}
		}
		return ""+numbers.pop();
	}

	public static void main(String[] args) {
		String s = "( ( ( 1 + 5 ) * 3 ) + 7 )";
		String sq = "( sqrt 3 )";
		String[] parts2 = sq.split(" ");
		String[] parts = s.split(" ");

		DijkstraCalculator Dijkstra = new DijkstraCalculator();
		System.out.println(Dijkstra.calculate(parts2));
		System.out.println(Dijkstra.calculate(parts));
		
	}
}