
public class Stack<T> {

	private T stack[];
	private int current;

	public Stack() {
		stack =  (T[]) new  Object[1];
		current = 0;
	}

	public void resize(int newCapacity) {
		T[] temp = (T[]) new Object[newCapacity];
		for (int i = 0; i < current; i++) {
			temp[i] = stack[i];
		}
		stack = temp;
	}

	public boolean isEmpty() {
		return current == 0;
	}

	public int size() {
		return current;
	}

	public void push(T item) {
		if (current == stack.length) {
			resize(2 * stack.length);
		}
		stack[current] = item;
		current++;
	}

	public T pop() {
		if (current == 0) {
			return null;
		}
		current--;
		if (current > 0 && current == stack.length / 4) {
			resize(stack.length / 2);
		}
		return stack[current];
	}
	
	
	

	public String toString() {
		String ret = "";
		for (int i = 0; i < current; i++) {
			ret += (stack[i] + " ");
		}
		return ret;
	}

}