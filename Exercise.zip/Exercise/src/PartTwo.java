import java.util.ArrayList;
import java.util.Arrays;

public class PartTwo {
 static ArrayList<Number> forTwoSum = new ArrayList<>();

	public static int twoSum(int[] a) {
		int n = a.length;
		int count = 0;
		for (int i = 0; i < n; i++) {
			for (int j = i + 1; j < n; j++) {
				
					if (a[i] + a[j] == 0) {
					if(forTwoSum.size()!=0) {
						boolean flag = false;
						for(int k = 0; k<forTwoSum.size(); k++) {
							if((a[i]==forTwoSum.get(k).num ) || a[i]==forTwoSum.get(k).counter) {
								flag=true;
								break;
							}
						}
						
						if(flag==false) {
							System.out.println(a[i] + " " + a[j] + " ");
							forTwoSum.add(new Number(a[i],a[j]));
							count++;
						}
					}else {
						System.out.println(a[i] + " " + a[j] + " ");
						forTwoSum.add(new Number(a[i],a[j]));
						count++;
						
					}
					
				}
				
			}
			
		}
		
		return count;
	}
	
	public static int twoSumFast(int[] a) {
		int n = a.length;
		Arrays.sort(a);
		int count = 0;
		for (int i = 0; i < n; i++) {
				int k = Arrays.binarySearch(a, -(a[i]));
				if (k > i) {
					count++;
					 System.out.println(a[i] + " " + a[k] + " ");

				
			}
		}
		return count;
	}
}
