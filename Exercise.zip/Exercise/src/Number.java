
public class Number {
	int num;
	int counter;

	public Number(int num, int counter) {
		this.num = num;
		this.counter = counter;

	}

	@Override
	public String toString() {
		return "Number [num=" + num + ", counter=" + counter + "]";
	}



}
