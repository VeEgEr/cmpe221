import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Scanner;

public class Test {

	public static void main(String[] args) throws IOException {

		int[] arr = getData();
/*
		StopWatch watchTS = new StopWatch();
		System.out.println("ThreeSum count: " + ThreeSum.count(arr));
		System.out.println("ThreeSum elapsed time: " + watchTS.elapsedTime());

		System.out.println();

		StopWatch watchTSF = new StopWatch();
		System.out.println("ThreeSumFast count: " + ThreeSumFast.count(arr));
		System.out.println("ThreeSumFast elapsed time: " + watchTSF.elapsedTime());
		*/
		System.out.println();
		//this algorithm takes too much time because it compares each index of array.
		StopWatch watchTwoSum = new StopWatch();
		System.out.println("TwoSum count:" + PartTwo.twoSum(arr));
		System.out.println("Twosum elapsed time:" + watchTwoSum.elapsedTime() );
		
		System.out.println();
		
		//this algorithm is faster than other because it uses binarysearch. binarysearch works by to split array and to check mid value is it bigger or lower?.
		StopWatch watchTwoSumFast = new StopWatch();
		System.out.println("TwoSumFast count:" + PartTwo.twoSumFast(arr));
		System.out.println("TwoSumFast elapsed time:" + watchTwoSumFast.elapsedTime() );
		
		
		
		
		
		
	}

	/*
	 * DATASETS
	 * 
	 * https://algs4.cs.princeton.edu/14analysis/1Kints.txt
	 * https://algs4.cs.princeton.edu/14analysis/2Kints.txt
	 * https://algs4.cs.princeton.edu/14analysis/4Kints.txt
	 * https://algs4.cs.princeton.edu/14analysis/8Kints.txt
	 * https://algs4.cs.princeton.edu/14analysis/16Kints.txt
	 * https://algs4.cs.princeton.edu/14analysis/32Kints.txt
	 * https://algs4.cs.princeton.edu/14analysis/1Mints.txt
	 * 
	 */

	public static int[] getData() throws IOException {
		URL textURL = new URL("https://algs4.cs.princeton.edu/14analysis/2Kints.txt");
		Scanner scanner = new Scanner(new InputStreamReader(textURL.openStream()));

		// change the size of arr when you change the URL
		int[] arr = new int[4000];
		int i = 0;

		while (scanner.hasNext()) {
			arr[i++] = scanner.nextInt();
		}
		
		for (int k = 0; k<arr.length/2; k++) {
			arr[k+2000]=arr[k];
			
		}

		scanner.close();

		return arr;
	}
}