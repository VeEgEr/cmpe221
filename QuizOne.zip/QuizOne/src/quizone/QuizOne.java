/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quizone;

import java.util.Timer;

/**
 *
 * @author veyisegemenerden
 */
public class QuizOne {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        QuizOne q1 = new QuizOne();
        long start1 = System.nanoTime();
        System.out.println(q1.Power(3,3));
        long finish1 = System.nanoTime();
         System.out.println("Power " +(finish1-start1));
        long start2 = System.nanoTime();
        System.out.println(q1.PowerRe(3, 3));
        long finish2 = System.nanoTime();
         System.out.println("PowerRe " +(finish2-start2));
        long start3 = System.nanoTime();
        q1.Fibonacci(5);
        long finish3 = System.nanoTime();
         System.out.println("Fibonacci " +(finish3-start3));
        long start4 = System.nanoTime();
        q1.FibonacciRe(5);
        long finish4 = System.nanoTime();
        System.out.println("FibonacciRe " +(finish4-start4));
    }
    
    public int Power(int x , int n){
       int result = x;
        for (int i = n ; i>0; i--){
        
            result = x * result;
          
        }
       
    return result/x;
    }
    
    
    public int PowerRe(int x , int n){
        if (n==0){
            return 1;
        }
        return x*(PowerRe(x,n-1));
    }
    
    
    
    
    
    public int Fibonacci(int x){
         int n1=0;
         int n2=1;
         int n3=0;    
 System.out.print(n1+" "+n2);   
    
 for(int i=2;i<x;i++){    
  n3=n1+n2;    
  System.out.print(" "+n3);    
  n1=n2;    
  n2=n3;    
 }    
  
return n3;
    
}
    
    
    
   public int FibonacciRe(int n)  {
    if(n == 0){
        return 0;}
    else if(n == 1){
      return 1;}
    else{
        System.out.print(FibonacciRe(n - 1) );
      return FibonacciRe(n - 1) + FibonacciRe(n - 2);
   }
  
   }
    
}
