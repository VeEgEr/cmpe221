import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Collections;
import java.util.PriorityQueue;
import java.util.Scanner;

public class Test {
	static int counterForInsertion=0;
	/*
	 * DATASETS
	 * 
	 * https://algs4.cs.princeton.edu/14analysis/1Kints.txt
	 * https://algs4.cs.princeton.edu/14analysis/2Kints.txt
	 * https://algs4.cs.princeton.edu/14analysis/4Kints.txt
	 * https://algs4.cs.princeton.edu/14analysis/8Kints.txt
	 * https://algs4.cs.princeton.edu/14analysis/16Kints.txt
	 * https://algs4.cs.princeton.edu/14analysis/32Kints.txt
	 * https://algs4.cs.princeton.edu/14analysis/1Mints.txt
	 * 
	 */

	public static void main(String[] args) throws IOException {

		Integer[] arr = getData();
		Test t = new Test();
		StopWatch watch1 = new StopWatch();
		t.toString(arr);
		System.out.println("insertion elapsed time:" + watch1.elapsedTime() );
		
		StopWatch watch2 = new StopWatch();
		findLargePriorty(arr);
		System.out.println("findLargePriorty elapsed time:" + watch2.elapsedTime() );
		
		StopWatch watch3 = new StopWatch();
		System.out.println("5th smallest:" + find5thSmallest(arr));
		System.out.println("find5thSmallest  elapsed time :" + watch3.elapsedTime() );
		
		StopWatch watch4 = new StopWatch();
		 find5thSmallestWithPriority(arr);
		System.out.println("find5thSmallestWithPriority  elapsed time :" + watch4.elapsedTime() );
	
	
	}

	public void toString(Integer[] arr) {
		findLarge(arr);
		for (int i = arr.length-1; i>=arr.length-5; i--) {
			
			System.out.println("5 largest: " + arr[i]);
		}
			
		
	}
	public static Integer[] getData() throws IOException {
		URL textURL = new URL("https://algs4.cs.princeton.edu/14analysis/4Kints.txt");
		Scanner scanner = new Scanner(new InputStreamReader(textURL.openStream()));

		// change the size of arr when you change the URL
		Integer[] arr = new Integer[4000];
		int i = 0;

		while (scanner.hasNext()) {
			arr[i++] = scanner.nextInt();
		}

		scanner.close();

		return arr;
	}
	
	
	public void findLarge(Integer [] arr) {
		 int temp;
	        for (int i = 1; i < arr.length; i++) {
	            for(int j = i ; j > 0 ; j--){
	                if(arr[j] < arr[j-1]){
	                	 counterForInsertion++;
	                    temp = arr[j];
	                    arr[j] = arr[j-1];
	                    arr[j-1] = temp;
	                }
	            }
	        }
	       
	}
	
	
	public static void findLargePriorty(Integer [] arr) {
		PriorityQueue<Integer> queue = new PriorityQueue<>(5, Collections.reverseOrder());
		for (int i = 0; i<arr.length; i++) {
			queue.offer(arr[i]);
		}
		//...

		Integer val = null;
		System.out.println();
		for (int i=0; i<5; i++) {
			val = queue.poll();
			
			System.out.println("5 largest with priority queue: "+ val);
		}
		
		
	}
	
	public static int find5thSmallest(Integer[]arr) {
		
		return arr[4];
	}
	
	public static void find5thSmallestWithPriority(Integer[]arr) {
		PriorityQueue<Integer> queue = new PriorityQueue<>(5, null);
		for (int i = 0; i<arr.length; i++) {
			queue.offer(arr[i]);
		}
		//...

		Integer val = null;
		System.out.println();
		for (int i=0; i<5; i++) {
			val = queue.poll();
			if(i==4) {
				System.out.println("5th smallest with priority: "+ val);
			}
			
			}
		
		
			
		
		
	}
	
	
	
	
	
}