package week01;

import java.util.Random;
import java.util.Scanner;
import java.util.Stack;

import org.omg.CORBA.Current;

public class Main {
	Stack st = new Stack();
	static int size = 0;
	
	public static void main(String[] args) {
		double a = System.currentTimeMillis();
		Person p = new Person("Egemen",22);
		Person s = new Person("ilayda",22);
		Person t = new Person("merve",22);
		
		Person[] arr = new Person[3];
		arr[0] = p;
		arr[1] = s;
		arr[2] = t;
		
		
		Main m = new Main();
		m.toPush(arr);
		m.display();
		
		
		Random rnd = new Random();
		
		int [ ] intArr = new int[999999];
		
		for (int i = 0; i<intArr.length; i++){
			intArr[i]= rnd.nextInt(99999);
		}
		long start = System.nanoTime();
		m.linearsearch(intArr, 5555);
		long finish = System.nanoTime();
		
		
		System.out.println(finish-start);
		
		
		
		
		Scanner sc = new Scanner(System.in);
		while (size>0){
			System.out.println("Do you want Pop?");
			String str = sc.nextLine();
			
			if (str != "no"){
			
				System.out.println(str);
				m.toPop();
				double b = System.currentTimeMillis();
				
				System.out.println(b-a);
				size--;
			}
			
			
			
		}
		
		System.out.println("Stack is empty.");
		
		
		
		
		
		
		
	}
	
	
	
	
	public void toPush(Person[] arr){
		for (int i = 0 ; i< arr.length; i++){
			
			System.out.println("Pushing ->  " + arr[i] );
        st.push(arr[i]);
        System.out.println("done");
			
		}
		size = st.size(); 
	}
	
	public void display(){
		System.out.println(st.toString());
		System.out.println("Size of Stack  =  " + st.size());
	}
	
	public void toPop(){
		
		 Person pop = (Person) st.pop();
		 System.out.println(pop + "is pop.");
		
	}
	
	
	
	public int linearsearch(int[] arr, int key){
		for(int i = 0; i<arr.length; i++){
			if(arr[i]== key){
				
				return i;
				
			}
			
			
		}
		
		return -1;
		
	}
}
